import webbrowser
import subprocess
import os
import sys
import time

def main():
    print("=" * 50)
    print("   _____                      _   ______ _          ")
    print("  / ____|                    | | |  ____(_)         ")
    print(" | (___  _ __ ___  __ _ _ __| |_| |__   _ _ __ ___  ")
    print("  \\___ \\| '__/ _ \\/ _` | '__| __|  __| | | '__/ _ \\ ")
    print("  ____) | | |  __/ (_| | |  | |_| |    | | | |  __/ ")
    print(" |_____/|_|  \\___|\\__,_|_|   \\__|_|    |_|_|  \\___| ")
    print("=" * 50)
    print()
    print("Starting SmartFixer Application...")
    print()
    print("Please wait while we launch SmartFixer in your browser...")
    print()
    
    try:
        # Get the directory where this script is located
        if getattr(sys, 'frozen', False):
            # If running as compiled executable
            script_dir = os.path.dirname(sys.executable)
        else:
            # If running as script
            script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Path to the main application
        launch_script = os.path.join(script_dir, "launch.py")
        
        # Start the server
        print("Starting server...")
        server_process = subprocess.Popen([sys.executable, launch_script], 
                                        cwd=script_dir,
                                        creationflags=subprocess.CREATE_NEW_CONSOLE)
        
        # Wait for server to start
        print("Server is starting...")
        time.sleep(5)
        
        # Open browser to the application
        print("Opening SmartFixer in your browser...")
        webbrowser.open("http://localhost:5000")
        
        print()
        print("SmartFixer is now running!")
        print("=" * 50)
        print("* The application is accessible at: http://localhost:5000")
        print("* To stop the application, close the server window")
        print("* For best experience, keep this window open")
        print("=" * 50)
        print()
        input("Press Enter to close this window...")
        
    except Exception as e:
        print(f"Error starting SmartFixer: {e}")
        input("Press Enter to close this window...")

if __name__ == "__main__":
    main()