SmartFixer Application
====================

Thank you for downloading SmartFixer!

To use this application:

1. Extract all files from this ZIP archive to a folder on your computer
2. Double-click "Run SmartFixer.bat" to start the application
3. The application will automatically open in your default web browser
4. To stop the application, close the command prompt window

System Requirements:
- Python 3.11 or higher installed on your system
- All required dependencies (will be installed automatically on first run)

For best experience, keep the command prompt window open while using the application.

If you encounter any issues, please make sure Python is installed and accessible from your command prompt.
