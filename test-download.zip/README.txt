SmartFixer Application
====================

Thank you for downloading SmartFixer!

This download contains the files needed to create a standalone executable application with an icon.

To create the full application with icon:

1. Extract all files from this ZIP archive to a folder on your computer
2. Install PyInstaller: pip install pyinstaller
3. Run: pyinstaller --onefile --windowed --icon=icon.ico SmartFixer-App.py
4. The executable will be created in the "dist" folder

For detailed instructions, read "HOW_TO_CREATE_APPLICATION.md"

To run the application directly (requires Python):
1. Extract all files
2. Double-click "Run SmartFixer.bat"

System Requirements:
- Python 3.11 or higher installed on your system

For best experience, keep the command prompt window open while using the application.
